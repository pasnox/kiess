#include "../iris/xmpp/xmpp-core/xmpp_stanza.h"
