#include "../iris/xmpp/xmpp-im/xmpp_rosteritem.h"
