#include "../iris/irisnet/noncore/legacy/safedelete.h"
