#include "../iris/irisnet/noncore/legacy/srvresolver.h"
