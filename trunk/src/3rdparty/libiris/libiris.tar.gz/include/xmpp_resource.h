#include "../iris/xmpp/xmpp-im/xmpp_resource.h"
